<script setup>
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'

import CategoryFilter from '@/components/event/CategoryFilter.vue'
import EventCard from '@/components/event/EventCard.vue'
import SearchBar from '@/components/event/SearchBar.vue'
import AppButton from '@/components/ui/AppButton.vue'
import AppCard from '@/components/ui/AppCard.vue'
import { useEvents } from '@/composables/useEvents'

const router = useRouter()
const searchQuery = ref('')
const selectedCategory = ref('All')
const { activeEvents } = useEvents()

const defaultCategories = ['Workshop', 'Meetup', 'Competition', 'Seminar', 'Conference']
const eventCategories = computed(() => [
  'All',
  ...new Set([
    ...defaultCategories,
    ...activeEvents.value.map((event) => event.cat).filter(Boolean),
  ]),
])

const emptyHeading = computed(() => {
  if (searchQuery.value.trim()) {
    return `No ${selectedCategory.value === 'All' ? '' : `${selectedCategory.value} `}events match your search`
  }

  if (selectedCategory.value !== 'All') {
    return activeEvents.value.length
      ? `No ${selectedCategory.value} events found`
      : `No ${selectedCategory.value} events yet`
  }

  return 'Your next great experience starts here'
})

const emptyMessage = computed(() => {
  if (activeEvents.value.length) {
    return 'Try another category or search term, or reset your filters to see all upcoming events.'
  }

  if (selectedCategory.value !== 'All') {
    return `There are no published ${selectedCategory.value} events yet. Create one to make it appear in the public catalog.`
  }

  return 'There are no events published yet. Check back soon or create an event for your community.'
})

const filteredEvents = computed(() => {
  const query = searchQuery.value.trim().toLowerCase()

  return activeEvents.value.filter((event) => {
    const matchesCategory = selectedCategory.value === 'All' || event.cat === selectedCategory.value
    const matchesSearch =
      !query ||
      [event.title, event.loc, event.desc, event.cat]
        .filter(Boolean)
        .some((value) => value.toLowerCase().includes(query))

    return matchesCategory && matchesSearch
  })
})

function openEventDetail(id) {
  router.push(`/browse/events/${id}`)
}

function resetFilters() {
  searchQuery.value = ''
  selectedCategory.value = 'All'
}
</script>

<template>
  <div class="event-list-page">
    <header class="page-heading">
      <h1>Upcoming Events</h1>
      <p>Discover workshops, seminars, tech meetups, and competitions near you.</p>
    </header>

    <div class="toolbar">
      <SearchBar v-model="searchQuery" />
      <CategoryFilter v-model="selectedCategory" :categories="eventCategories" />
    </div>

    <div v-if="filteredEvents.length" class="event-grid">
      <EventCard v-for="event in filteredEvents" :key="event.id" :event="event" @view-detail="openEventDetail" />
    </div>

    <AppCard v-else class="empty-state">
      <div class="empty-illustration" aria-hidden="true">✦</div>
      <h3>{{ emptyHeading }}</h3>
      <p>{{ emptyMessage }}</p>
      <div class="empty-actions">
        <AppButton v-if="activeEvents.length" variant="secondary" @click="resetFilters">
          Reset filters
        </AppButton>
        <AppButton as="router-link" to="/dashboard/events" variant="primary">
          Host an event
        </AppButton>
      </div>
    </AppCard>
  </div>
</template>

<style scoped>
.event-list-page {
  width: 100%;
  max-width: 1100px;
  min-width: 0;
  margin-inline: auto;
}

.page-heading {
  margin: var(--space-6) 0 var(--space-6);
}

.page-heading h1 {
  margin: 0 0 var(--space-2);
  color: var(--text-main);
  font-size: clamp(1.7rem, 4vw, 2.2rem);
  font-weight: 750;
}

.page-heading p {
  margin: 0;
  color: var(--text-muted);
  line-height: 1.6;
}

.toolbar {
  margin-bottom: var(--space-6);
}

.event-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(min(100%, 300px), 1fr));
  gap: var(--space-6);
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: var(--space-4);
  padding: 2rem;
}

.empty-illustration {
  display: grid;
  width: 64px;
  height: 64px;
  place-items: center;
  border-radius: 18px;
  background: rgba(102, 68, 255, 0.1);
  color: var(--primary);
  font-size: 2rem;
}

.empty-state h3 {
  margin: 0;
  font-size: 1.6rem;
  color: var(--text-main);
}

.empty-state p {
  margin: 0;
  color: var(--text-muted);
  line-height: 1.6;
}

.empty-actions {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-3);
}
</style>
